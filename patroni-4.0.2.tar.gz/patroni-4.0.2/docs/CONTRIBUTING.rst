.. _contributing:

Contributing
============

Resources and information for developers can be found in the pages below.

.. toctree::
   :maxdepth: 2

   contributing_guidelines
   Patroni API docs<modules/modules>
