#!/usr/bin/env python
from patroni.raft_controller import main


if __name__ == '__main__':
    main()
